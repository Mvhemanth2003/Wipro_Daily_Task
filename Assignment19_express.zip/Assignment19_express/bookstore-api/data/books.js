let books = [
    { id: 1, title: "Book One", author: "Author A", price: 150 },
    { id: 2, title: "Book Two", author: "Author B", price: 250 }
];

module.exports = books;